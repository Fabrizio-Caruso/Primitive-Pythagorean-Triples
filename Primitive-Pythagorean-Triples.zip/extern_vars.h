
extern unsigned short count;
#pragma zpsym("count")
extern number_t *tail;
extern number_t *head;
#pragma zpsym("tail")
#pragma zpsym("head")

extern number_t a,b,c;
#pragma zpsym("a");
#pragma zpsym("b");
#pragma zpsym("c");	

extern number_t a1,b1;
#pragma zpsym("a1");
#pragma zpsym("b1");
extern number_t a2;
#pragma zpsym("a2");	
extern number_t da, db, dc, tc;
#pragma zpsym("da");
#pragma zpsym("db");
#pragma zpsym("dc");
#pragma zpsym("tc");		
extern number_t s;
#pragma zpsym("s");	
