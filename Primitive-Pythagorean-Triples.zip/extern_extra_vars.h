
extern number_t c1;
#pragma zpsym("c1");	
extern number_t a3,b3,c3;
#pragma zpsym("a2");
#pragma zpsym("a3");
#pragma zpsym("b3");
#pragma zpsym("c3");

